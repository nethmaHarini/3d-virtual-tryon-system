const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const nodemailer = require("nodemailer");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");
const pool = require("./db");

require("dotenv").config();

const app = express();
const SECRET = process.env.JWT_SECRET || "your_secret_key";
const FRONTEND_URL = process.env.FRONTEND_URL || "http://localhost:5174";
const BACKEND_PUBLIC_URL =
  process.env.BACKEND_PUBLIC_URL || "http://localhost:3000";
const GENERATED_AVATAR_DIR = path.join(__dirname, "generated-avatars");
const TMP_UPLOAD_DIR = path.join(__dirname, "tmp-uploads");
const PYTHON_SCRIPT = path.join(__dirname, "python", "generate_avatar.py");
const SAMPLE_OBJ = path.join(__dirname, "python", "sample_avatar.obj");

fs.mkdirSync(GENERATED_AVATAR_DIR, { recursive: true });
fs.mkdirSync(TMP_UPLOAD_DIR, { recursive: true });

const saveTempBufferToFile = (buffer, filename) => {
  const fullPath = path.join(TMP_UPLOAD_DIR, filename);
  fs.writeFileSync(fullPath, buffer);
  return fullPath;
};

const removeFileIfExists = (filePath) => {
  try {
    if (filePath && fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  } catch (error) {
    console.error("Temp file cleanup failed:", error);
  }
};

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_APP_PASSWORD,
  },
});

app.use(cors({ origin: "*" }));
app.use(express.json());
app.use("/generated-avatars", express.static(path.join(__dirname, "generated-avatars")));

// Privacy-safe upload handling: keep files in memory only for temporary processing.
// Raw photos are not written to disk or permanently stored by this backend flow.
const storage = multer.memoryStorage();

const upload = multer({
  storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5 MB each
  },
});

app.get("/", (req, res) => {
  res.send("Backend is running successfully 🚀");
});

const isValidEmail = (email) => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};

const isStrongPassword = (password) => {
  return typeof password === "string" && password.length >= 6;
};

const normalizeUsername = (value) => {
  const base = (value || "user")
    .toLowerCase()
    .replace(/[^a-z0-9_]/g, "")
    .slice(0, 20);

  if (base.length >= 3) {
    return base;
  }

  return `${base}user`.slice(0, 20);
};

const createUniqueUsername = async (seed) => {
  const base = normalizeUsername(seed);
  let candidate = base;
  let attempts = 0;

  while (attempts < 20) {
    const existing = await pool.query(
      "SELECT 1 FROM users WHERE username = $1",
      [candidate],
    );

    if (existing.rows.length === 0) {
      return candidate;
    }

    const suffix = Math.floor(1000 + Math.random() * 9000).toString();
    candidate = `${base.slice(0, Math.max(3, 20 - suffix.length))}${suffix}`;
    attempts += 1;
  }

  return `${base.slice(0, 15)}${Date.now().toString().slice(-5)}`;
};

const createAuthToken = (user) => {
  return jwt.sign({ id: user.id, email: user.email }, SECRET, {
    expiresIn: "1h",
  });
};

app.post("/register", async (req, res) => {
  const { username, email, password } = req.body;

  if (!username || !email || !password) {
    return res.status(400).json({
      message: "Username, email and password are required",
    });
  }

  if (username.trim().length < 3) {
    return res.status(400).json({
      message: "Username must be at least 3 characters",
    });
  }

  if (!isValidEmail(email)) {
    return res.status(400).json({
      message: "Please provide a valid email address",
    });
  }

  if (!isStrongPassword(password)) {
    return res.status(400).json({
      message: "Password must be at least 6 characters",
    });
  }

  try {
    const existingUser = await pool.query(
      "SELECT * FROM users WHERE email = $1 OR username = $2",
      [email, username],
    );

    if (existingUser.rows.length > 0) {
      return res.status(400).json({
        message: "Email or username already exists",
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    await pool.query(
      "INSERT INTO users (username, email, password) VALUES ($1, $2, $3)",
      [username, email, hashedPassword],
    );

    res.json({ message: "Registration successful" });
  } catch (error) {
    console.error("Register error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

app.post("/login", async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({
      message: "Email and password are required",
    });
  }

  if (!isValidEmail(email)) {
    return res.status(400).json({
      message: "Please provide a valid email address",
    });
  }

  if (!isStrongPassword(password)) {
    return res.status(400).json({
      message: "Password must be at least 6 characters",
    });
  }

  try {
    const result = await pool.query("SELECT * FROM users WHERE email = $1", [
      email,
    ]);

    if (result.rows.length === 0) {
      return res.status(401).json({
        message: "Invalid email or password",
      });
    }

    const user = result.rows[0];

    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.status(401).json({
        message: "Invalid email or password",
      });
    }

    const token = createAuthToken(user);

    res.json({
  message: "Login successful",
  token,
  user: {
    id: user.id,
    username: user.username,
    email: user.email,
  },
});
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

app.post("/auth/google", async (req, res) => {
  const { code } = req.body;

  if (!code) {
    return res.status(400).json({
      message: "Google authorization code is required",
    });
  }

  try {
    // Exchange authorization code for access token
    const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        client_id: process.env.GOOGLE_CLIENT_ID,
        client_secret: process.env.GOOGLE_CLIENT_SECRET,
        code: code,
        grant_type: "authorization_code",
        redirect_uri: `${process.env.FRONTEND_URL}`,
      }),
    });

    if (!tokenResponse.ok) {
      console.error("Token exchange failed:", await tokenResponse.text());
      return res.status(401).json({
        message: "Failed to exchange Google authorization code",
      });
    }

    const tokenData = await tokenResponse.json();
    const accessToken = tokenData.access_token;

    if (!accessToken) {
      return res.status(401).json({
        message: "No access token received from Google",
      });
    }

    // Get user info using access token
    const googleResponse = await fetch(
      "https://www.googleapis.com/oauth2/v3/userinfo",
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      },
    );

    if (!googleResponse.ok) {
      return res.status(401).json({
        message: "Invalid Google token",
      });
    }

    const googleUser = await googleResponse.json();
    const googleEmail = googleUser?.email;

    if (!googleEmail || !isValidEmail(googleEmail)) {
      return res.status(400).json({
        message: "Google account email is not available",
      });
    }

    const existingUser = await pool.query(
      "SELECT * FROM users WHERE email = $1",
      [googleEmail],
    );

    if (existingUser.rows.length > 0) {
      const token = createAuthToken(existingUser.rows[0]);

      return res.json({
        message: "Google login successful",
        token,
        user: {
          username: existingUser.rows[0].username,
          email: existingUser.rows[0].email,
        },
      });
    }

    const generatedUsername = await createUniqueUsername(
      googleUser?.name || googleEmail.split("@")[0],
    );
    const generatedPassword = `google_${Math.random().toString(36).slice(2, 14)}`;
    const hashedPassword = await bcrypt.hash(generatedPassword, 10);

    const insertedUser = await pool.query(
      "INSERT INTO users (username, email, password) VALUES ($1, $2, $3) RETURNING id, username, email",
      [generatedUsername, googleEmail, hashedPassword],
    );

    const token = createAuthToken(insertedUser.rows[0]);

    return res.status(201).json({
      message: "Google account created and login successful",
      token,
      user: insertedUser.rows[0],
    });
  } catch (error) {
    console.error("Google auth error:", error);
    return res.status(500).json({ message: "Server error" });
  }
});

app.post("/forgot-password", async (req, res) => {
  const { email } = req.body;

  if (!email) {
    return res.status(400).json({ message: "Email is required" });
  }

  if (!isValidEmail(email)) {
    return res
      .status(400)
      .json({ message: "Please provide a valid email address" });
  }

  try {
    const result = await pool.query("SELECT * FROM users WHERE email = $1", [
      email,
    ]);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    // Generate token
    const token = crypto.randomBytes(32).toString("hex");

    // Save token in DB
    await pool.query("UPDATE users SET reset_token = $1 WHERE email = $2", [
      token,
      email,
    ]);

    const resetLink = `${FRONTEND_URL}/reset-password/${token}`;

    await transporter.sendMail({
      from: process.env.GMAIL_USER,
      to: email,
      subject: "Reset your password",
      html: `
        <p>You requested to reset your password.</p>
        <p>Click the link below to continue:</p>
        <a href="${resetLink}">${resetLink}</a>
      `,
    });

    return res.json({ message: "Password reset email sent" });
  } catch (error) {
    console.error("Forgot password error:", error);
    return res.status(500).json({ message: "Server error" });
  }
});

app.post("/reset-password/:token", async (req, res) => {
  const { token } = req.params;
  const { password } = req.body;

  if (!token) {
    return res.status(400).json({ message: "Reset token is required" });
  }

  if (!isStrongPassword(password)) {
    return res
      .status(400)
      .json({ message: "Password must be at least 6 characters" });
  }

  try {
    const result = await pool.query(
      "SELECT id FROM users WHERE reset_token = $1",
      [token],
    );

    if (result.rows.length === 0) {
      return res
        .status(400)
        .json({ message: "Invalid or expired reset token" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    await pool.query(
      "UPDATE users SET password = $1, reset_token = NULL WHERE id = $2",
      [hashedPassword, result.rows[0].id],
    );

    return res.json({ message: "Password reset successful" });
  } catch (error) {
    console.error("Reset password error:", error);
    return res.status(500).json({ message: "Server error" });
  }
});

app.post(
  "/generate-avatar",
  upload.fields([
    { name: "frontImage", maxCount: 1 },
    { name: "backImage", maxCount: 1 },
    { name: "sideImage", maxCount: 1 },
  ]),
  async (req, res) => {
    let frontPath = null;
    let backPath = null;
    let sidePath = null;

    try {
      const { height } = req.body;

      const frontImage = req.files?.frontImage?.[0];
      const backImage = req.files?.backImage?.[0];
      const sideImage = req.files?.sideImage?.[0];

      if (!frontImage || !backImage || !sideImage) {
        return res.status(400).json({
          message: "Front, back, and side images are required",
        });
      }

      if (!height) {
        return res.status(400).json({
          message: "Height is required",
        });
      }

      const numericHeight = Number(height);

      if (Number.isNaN(numericHeight) || numericHeight < 100 || numericHeight > 250) {
        return res.status(400).json({
          message: "Height must be between 100 and 250 cm",
        });
      }

      const timestamp = Date.now();
      const avatarFilename = `avatar_${timestamp}.obj`;
      const outputPath = path.join(GENERATED_AVATAR_DIR, avatarFilename);

      frontPath = saveTempBufferToFile(frontImage.buffer, `front_${timestamp}.jpg`);
      backPath = saveTempBufferToFile(backImage.buffer, `back_${timestamp}.jpg`);
      sidePath = saveTempBufferToFile(sideImage.buffer, `side_${timestamp}.jpg`);

      const pythonArgs = [
        PYTHON_SCRIPT,
        "--front",
        frontPath,
        "--back",
        backPath,
        "--side",
        sidePath,
        "--height",
        String(numericHeight),
        "--body_model",
        "neutral",
        "--output",
        outputPath,
        "--sample_obj",
        SAMPLE_OBJ,
      ];

      const pythonCommand =
        process.platform === "win32" ? "python" : "python3";

      const pythonProcess = spawn(pythonCommand, pythonArgs, {
        cwd: __dirname,
      });

      let stdout = "";
      let stderr = "";

      pythonProcess.stdout.on("data", (data) => {
        stdout += data.toString();
      });

      pythonProcess.stderr.on("data", (data) => {
        stderr += data.toString();
      });

      pythonProcess.on("close", async (code) => {
        removeFileIfExists(frontPath);
        removeFileIfExists(backPath);
        removeFileIfExists(sidePath);

        if (code !== 0) {
          console.error("Python generation failed:", stderr || stdout);
          return res.status(500).json({
            message: "Avatar generation failed",
            error: stderr || stdout,
          });
        }

        let parsed;
        try {
          parsed = JSON.parse(stdout.trim());
        } catch (error) {
          console.error("Invalid Python output:", stdout);
          return res.status(500).json({
            message: "Invalid generator response",
          });
        }

        if (!parsed.success) {
          return res.status(500).json({
            message: parsed.message || "Avatar generation failed",
          });
        }

        const avatarBaseUrl = `${req.protocol}://${req.get("host")}`;
        const avatarUrl = `${avatarBaseUrl}/generated-avatars/${avatarFilename}`;

        return res.status(200).json({
          message: "Avatar generated successfully",
          avatarUrl,
          avatar: {
            avatar_file: avatarUrl,
            generated_at: new Date().toISOString(),
            height: numericHeight,
          },
        });
      });
    } catch (error) {
      removeFileIfExists(frontPath);
      removeFileIfExists(backPath);
      removeFileIfExists(sidePath);

      console.error("Generate avatar error:", error);
      return res.status(500).json({
        message: "Server error during avatar generation",
        error: error.message,
      });
    }
  },
);

// Serve generated avatars statically

// Mock Fit Analysis API
app.post("/fit-analysis", (req, res) => {
  res.json({
    bodyRegions: [
      { name: "Chest", status: "Tight" },
      { name: "Waist", status: "Perfect" },
      { name: "Hip", status: "Loose" }
    ],
    recommendation:
      "Recommended size is based on AI analysis. Consider adjusting garment fit for better comfort."
  });
});


// Save Fit Analysis API
app.post("/save-fit", async (req, res) => {
  const { userId, chest, waist, hip, recommendation } = req.body;

  // temporary log (later save to DB)
  console.log(req.body);

  res.json({ message: "Fit analysis saved" });
});

app.use("/generated-avatars", express.static("generated-avatars"));

const PORT = process.env.PORT || 3000;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server running on port ${PORT}`);
});
